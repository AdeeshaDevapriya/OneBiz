OnePageBiz - React + TypeScript + Tailwind template
--------------------------------------------------

Quick start:
  1) Install dependencies:
     yarn install  (or npm install)
  2) Run dev server:
     yarn dev
  3) Build for production:
     yarn build

Notes:
  - This is a demo single-page business template. To enable contact form integration, replace the simulated submit in Contact.tsx with EmailJS / Formspree or your backend endpoint.
  - Deploy on Vercel / Netlify by pushing to GitHub and connecting the repo.