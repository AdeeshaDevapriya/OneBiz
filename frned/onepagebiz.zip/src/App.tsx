import React from 'react'
import Hero from './components/Hero'
import About from './components/About'
import Services from './components/Services'
import Contact from './components/Contact'
import Footer from './components/Footer'

export default function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 bg-white/80 backdrop-blur z-30 shadow-sm">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded bg-blue-600 flex items-center justify-center text-white font-bold">B</div>
            <div>
              <div className="font-bold">BusinessName</div>
              <div className="text-xs text-gray-500">Modern websites for small businesses</div>
            </div>
          </div>
          <nav className="hidden md:flex gap-6 text-sm">
            <a href="#about" className="hover:text-blue-600">About</a>
            <a href="#services" className="hover:text-blue-600">Services</a>
            <a href="#contact" className="hover:text-blue-600">Contact</a>
          </nav>
          <a href="#contact" className="ml-4 bg-blue-600 text-white px-4 py-2 rounded text-sm">Contact</a>
        </div>
      </header>

      <main className="flex-1">
        <Hero />
        <About />
        <Services />
        <Contact />
      </main>

      <Footer />
    </div>
  )
}