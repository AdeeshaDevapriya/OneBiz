import React from 'react'

export default function Hero() {
  return (
    <section className="py-20 bg-gradient-to-b from-white to-blue-50">
      <div className="container text-center">
        <h1 className="text-4xl md:text-5xl font-extrabold mb-4">Make your business shine online</h1>
        <p className="text-gray-600 mb-6">Professional, affordable single-page websites for local shops and small businesses.</p>
        <div className="flex items-center justify-center gap-4">
          <a href="#contact" className="bg-blue-600 text-white px-6 py-3 rounded-md font-medium">Get a Website</a>
          <a href="https://wa.me/947XXXXXXXX" className="border border-blue-600 text-blue-600 px-6 py-3 rounded-md font-medium">WhatsApp</a>
        </div>
        <div className="mt-8">
          <img src="/demo-screenshot.png" alt="demo" className="mx-auto rounded shadow-md w-full max-w-3xl" />
        </div>
      </div>
    </section>
  )
}