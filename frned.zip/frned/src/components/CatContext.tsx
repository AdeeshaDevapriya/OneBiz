import { createContext } from "react";

export const CatContext = createContext("yoooo");
