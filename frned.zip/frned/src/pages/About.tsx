export default function About() {
  return (
    <div>
      <h1>About Page</h1>
      <p>This is a sample multi-page React TypeScript app using React Router.</p>
    </div>
  );
}
